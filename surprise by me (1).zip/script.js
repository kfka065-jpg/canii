const music = document.getElementById("music");

let playing = false;


function openSurprise() {
  
  const surprise = document.getElementById("surprise");
  
  surprise.classList.remove("hidden");
  
  music.play()
    .then(() => {
      playing = true;
      updateMusicButton();
    })
    .catch(() => {
      playing = false;
    });
  
  setTimeout(() => {
    surprise.scrollIntoView({
      behavior: "smooth"
    });
  }, 200);
  
}


function toggleMusic() {
  
  if (music.paused) {
    
    music.play();
    
    playing = true;
    
  } else {
    
    music.pause();
    
    playing = false;
    
  }
  
  updateMusicButton();
  
}


function updateMusicButton() {
  
  const button = document.querySelector(".music-btn");
  
  if (playing) {
    
    button.innerHTML = "🔊";
    
  } else {
    
    button.innerHTML = "🔇";
    
  }
  
}


async function sharePage() {
  
  const shareData = {
    title: "For You 💙",
    text: "Aku punya kejutan kecil buat kamu ✨",
    url: window.location.href
  };
  
  try {
    
    if (navigator.share) {
      
      await navigator.share(shareData);
      
    } else {
      
      await navigator.clipboard.writeText(window.location.href);
      
      alert("Link sudah disalin! 💙");
      
    }
    
  } catch (error) {
    
    console.log("Share dibatalkan.");
    
  }
  
}


music.addEventListener("play", () => {
  
  playing = true;
  
  updateMusicButton();
  
});


music.addEventListener("pause", () => {
  
  playing = false;
  
  updateMusicButton();
  
});